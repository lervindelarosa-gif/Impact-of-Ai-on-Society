presentation # Impact-of-Ai-on-Society
https://docs.google.com/presentation/d/1e96izGIhpdTc05RWw8WWFvKfSj6GoisbJwf8ZZwPou0/edit?slide=id.h5796b2af22730e91_47_31#slide=id.h5796b2af22730e91_47_31
